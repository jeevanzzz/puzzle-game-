package jeevan.picture_puzzle;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.text.DecimalFormat;
import java.time.Duration;
import java.util.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.util.List;

class MyButton extends JButton{
	private static final long serialVersionUID = 1L;
	boolean islastButton;
	
	public MyButton(boolean isLastButton) {
		this.islastButton = isLastButton;
		setBorder(null);
		init();
	}
	
	public MyButton(Image iconImage, boolean isLastButton) {
		setIcon(new ImageIcon(iconImage));
		this.islastButton = isLastButton;
		setBorder(null);
		init();
	}
	
	private void init(){
		if(!islastButton) {
			BorderFactory.createLineBorder(Color.GRAY);
			addMouseListener(new MouseAdapter() {
				public void mouseEntered(MouseEvent e) {
					setBorder(BorderFactory.createLineBorder(Color.YELLOW));
				}
				public void mouseExited(MouseEvent e) {
					setBorder(BorderFactory.createLineBorder(Color.GRAY));
				}
			});
		}
		else {
			BorderFactory.createLineBorder(Color.CYAN);
			addMouseListener(new MouseAdapter() {
				public void mouseEntered(MouseEvent e) {
					setBorder(BorderFactory.createLineBorder(Color.GREEN));
				}
				public void mouseExited(MouseEvent e) {
					setBorder(BorderFactory.createLineBorder(Color.CYAN));
				}
			});
		}
	}
}

public class PicturePuzzle extends JFrame implements ActionListener{
	private static final long serialVersionUID = 1L;
	JPanel northWrapper, centerWrapper, southWrapper;
	JLabel topLabel, starImageLabel;
	JButton mainMenu, solutionImage, timeButton, clickButton;
	BufferedImage sourceImage, resizedImage;
	Image createdImage;
	int width, height;
	long beforeTime;
	String timeTaken;
	boolean timeFlag;
	int clicks;
	Scanner sc = new Scanner(System.in);
	Image iconImage = Toolkit.getDefaultToolkit().getImage("src\\resources\\puzzle-icon.png").getScaledInstance(80, 80, Image.SCALE_SMOOTH);
	int pictureFlag;
	List<MyButton> buttons;
	List<Point> solution;
	final int NUMBER_OF_BUTTONS = 12;
	final int DESIRED_WIDTH = 300;
	
	public PicturePuzzle() {
		System.out.println("Which picture puzzle do you want to play? \n1. ST AGNES ADMINISTRATIVE BLOCK \n2. ST AGNES INSTITUTION \n3.ST AGNES SCHOOL ");
		int numberChosen = sc.nextInt();
		switch(numberChosen) {
		case 1: pictureFlag = 1; break;
		case 2: pictureFlag = 2; break;
		case 3: pictureFlag = 3; break;
		default: pictureFlag = 1;
		}

		solution = new ArrayList<>();		
		solution.add(new Point(0, 0));
		solution.add(new Point(0, 1));
		solution.add(new Point(0, 2));
		solution.add(new Point(1, 0));
		solution.add(new Point(1, 1));
		solution.add(new Point(1, 2));
		solution.add(new Point(2, 0));
		solution.add(new Point(2, 1));
		solution.add(new Point(2, 2));
		solution.add(new Point(3, 0));
		solution.add(new Point(3, 1));
		solution.add(new Point(3, 2));
		
		buttons = new ArrayList<>();
		if(centerWrapper != null) { 
			centerWrapper.removeAll();
		}
		centerWrapper = new JPanel();
		centerWrapper.setBorder(BorderFactory.createLineBorder(Color.GRAY));
		centerWrapper.setLayout(new GridLayout(4, 3, 0, 0));
		
		try {
			sourceImage = loadImage();
			int h = getNewHeight(sourceImage.getWidth(), sourceImage.getHeight());
			resizedImage = resizeImage(sourceImage, DESIRED_WIDTH, h, BufferedImage.TYPE_INT_ARGB);
		} catch(IOException e) {
			e.printStackTrace();
		}
		
		width = resizedImage.getWidth(null);
		height = resizedImage.getHeight(null);
		MyButton lastButton = null;
		
		for(int i = 0; i < 4; i++) {
			for(int j = 0; j < 3; j++) {
				createdImage = createImage(new FilteredImageSource(resizedImage.getSource(),
						new CropImageFilter(j * width  / 3, i * height / 4, width / 3, height / 4)));
				if(i == 3 && j == 2) { 
					lastButton = new MyButton(createdImage, true);
					lastButton.putClientProperty("position", new Point(i, j));
				}
				else {
					MyButton button = new MyButton(createdImage, false);
					button.putClientProperty("position", new Point(i, j));
					buttons.add(button);
				}
			}
		}
		
		Collections.shuffle(buttons);
		buttons.add(lastButton);
		for(int i = 0; i < NUMBER_OF_BUTTONS; i++) {
			JButton button = buttons.get(i);
			centerWrapper.add(button);
			button.addActionListener(new ClickAction());
		}
		add(centerWrapper, BorderLayout.CENTER);
		
		Image starImage = Toolkit.getDefaultToolkit().getImage("src\\resources\\star-icon.png").getScaledInstance(16, 16, Image.SCALE_SMOOTH);
		topLabel = new JLabel("Star icon swaps with its neighouring icon");
		starImageLabel = new JLabel(new ImageIcon(starImage));
		northWrapper = new JPanel();
		northWrapper.add(topLabel);  northWrapper.add(starImageLabel);
		
		mainMenu = new JButton("Menu");
		mainMenu.addActionListener(this);
		solutionImage = new JButton("Solution");
		solutionImage.addActionListener(this);
		timeButton = new JButton("00 : 00");
		timeButton.setToolTipText("Time Taken");
		clickButton = new JButton("0");
		clickButton.setToolTipText("Total Clicks");
		southWrapper = new JPanel();
		southWrapper.add(mainMenu);  southWrapper.add(solutionImage);  southWrapper.add(timeButton);  southWrapper.add(clickButton);
		
		add(northWrapper, BorderLayout.NORTH);
		add(centerWrapper, BorderLayout.CENTER);
		add(southWrapper, BorderLayout.SOUTH);
		
		pack();
		setTitle("Picture Puzzle");
		setLayout(new BorderLayout());
		setIconImage(iconImage);
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new PicturePuzzle();
			}
		});
	}
	
	private BufferedImage loadImage() throws IOException{
		BufferedImage sourceImage = null;
		if(pictureFlag == 1)
			sourceImage = ImageIO.read(new File("src\\resources\\ST AGNES ADMINISTRATIVE BLOCK.jpg"));
		else if(pictureFlag == 2)
			sourceImage = ImageIO.read(new File("src\\resources\\ST AGNES INSTITUTION.jpg"));
		else if(pictureFlag == 3)
			sourceImage = ImageIO.read(new File("src\\resources\\ST AGNES SCHOOL.jpg"));
		return sourceImage;
	}
	
	private int getNewHeight(int width, int height) {
		double ratio = DESIRED_WIDTH / (double) width;
		int newHeight = (int) (height * ratio);
		return newHeight;
	}
	
	private BufferedImage resizeImage(BufferedImage sourceImage, int width, int height, int type) {
		BufferedImage resizedImage = new BufferedImage(width, height, type);
		Graphics g = resizedImage.createGraphics();
		g.drawImage(sourceImage, 0, 0, width, height, null);
		g.dispose();
		return resizedImage;
	}
	
	class ClickAction extends AbstractAction {
		private static final long serialVersionUID = 1L;
		@Override
		public void actionPerformed(ActionEvent e) {
			if(!timeFlag) {
				beforeTime = System.currentTimeMillis();
				timeFlag = true;
				countdownTime();
			}
			clicks++;
			clickButton.setText("" + clicks);
			checkButton(e);
			checkSolution();
		}
		
		private void checkButton(ActionEvent e) {
			int lidx = 0;
			for(MyButton button: buttons) {
				if(button.islastButton) {
					lidx = buttons.indexOf(button);
				}
			}
			JButton button = (JButton) e.getSource();
			int bidx = buttons.indexOf(button);
			if((bidx - 1 == lidx) || (bidx + 1 == lidx) || (bidx -3 == lidx) || (bidx + 3 == lidx)) {
				Collections.swap(buttons, bidx, lidx);
				updateButtons();
			}
		}
		
		private void updateButtons() {
			centerWrapper.removeAll();
			for(MyButton button: buttons) {
				centerWrapper.add(button);
			}
			centerWrapper.validate();
		}
		
		private void checkSolution() {
			List<Point> current = new ArrayList<>();
			for(MyButton button: buttons) {
				current.add((Point) button.getClientProperty("position"));
			}
			if(compareList(solution, current)) {
				timeFlag = false;
				String message = "";
				if(pictureFlag == 1) message = "Sergio Ramos won 4 Champions League Titles";
				else if(pictureFlag == 2) message = "Cristiano Ronaldo won the Euro 2016";
				else if(pictureFlag == 3) message = "Luka Modric won Ballon D'or 2018";
				JOptionPane.showMessageDialog(centerWrapper, "Congratulations!\n" + message, 
					"You Won! Time: "+ timeTaken + " Clicks: " + clicks, JOptionPane.INFORMATION_MESSAGE);
				clicks = 0;
				timeTaken = null;
			}
		}
		
		public boolean compareList(List<Point> list1, List<Point> list2) {
			return list1.toString().contentEquals(list2.toString());
		}
	}

	public void countdownTime() {
		Thread t = new Thread(new Runnable() {
			@Override
			public void run() {
				while(timeFlag) {
					long currentTime = System.currentTimeMillis();
					long runninTime = currentTime - beforeTime;
					Duration duration = Duration.ofMillis(runninTime);
					long minutes = duration.toMinutes();
					duration = duration.minusMinutes(minutes);
					long seconds = (duration.toMillis())/1000; 
					DecimalFormat formatter = new DecimalFormat("00");
					timeTaken = formatter.format(minutes) + " : " + formatter.format(seconds);
					timeButton.setText(timeTaken);
				}
			}
		});
		t.start();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == mainMenu) {
			int reply = JOptionPane.showConfirmDialog(this, "Progress will be lost. Continue?", "Confirm", JOptionPane.YES_NO_OPTION);
			if(reply == JOptionPane.YES_OPTION) {
				timeFlag = false;
				clicks = 0;
				dispose();
				new PicturePuzzle();
			}
		}
		if(e.getSource() == solutionImage) {
			JDialog dialog = new JDialog();
			dialog.setTitle("Solution");
			Image dialogIcon = Toolkit.getDefaultToolkit().getImage("src\\resources\\correct-mark-icon.png");
			dialog.setIconImage(dialogIcon);
			Image solutionImage = null;
			try {
				solutionImage = loadImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			JLabel label = new JLabel(new ImageIcon(solutionImage));
			dialog.add(label);
			dialog.pack();
			dialog.setVisible(true);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		}
	}
}